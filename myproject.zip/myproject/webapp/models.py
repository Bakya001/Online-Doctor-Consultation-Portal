from django.db import models

class Patient(models.Model):
    Patientname=models.CharField(max_length=10)
    Patient_id=models.IntegerField()
    PatientEmail=models.EmailField(max_length=50)
    PatientAge=models.IntegerField()
    PatientGender=models.CharField(max_length=10)

    def __str__(self):
        return self.Patientname

